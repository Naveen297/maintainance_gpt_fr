export const API_BASE_URL = 'http://maintenancegpt.m-devsecops.com';
